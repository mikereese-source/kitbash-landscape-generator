# KitBash Landscape Generator — Parking List

Ideas that come up mid-build land here, not in the current milestone. Review at every gate.

| Idea | Raised | Raised during | Gate decision |
|------|--------|---------------|---------------|
| Stamps and curves: river curve, crater, volcano cone, U-valley | 2026-10-22 | Pre-build | Pending |
| Seamless tiling + heightmap export (for Unreal) | 2026-10-22 | Pre-build | Pending |
| Scatter rocks and plants using the masks | 2026-10-22 | Pre-build | Pending |
| three.js version for Cargo (standalone, same type JSON) | 2026-10-22 | Pre-build | → Project 2 (own build, after Project 1 Gold) — see D7 |
| Quick scale keeps the Width:Depth ratio when one side hits the 1 m minimum | 2026-10-22 | M1 | → M7 (edge cases) |
| Editing a landscape in Edit Mode does nothing (its base mesh is empty; the shape comes from the node group). Add a "Make Editable" button that applies it to a real mesh for sculpting | 2026-10-22 | M1 | Pending |
| Realism check: measure real elevation data (DEMs) for each type's reference place (slope histogram, relief ratio, roughness, hypsometric curve) and tune recipes until ours match; make it an automated part of T6 | 2026-10-22 | M1 | → M2 (Mike, 2026-10-22) |
| "Real terrain" option: import a free DEM tile (e.g. Copernicus GLO-30, USGS 3DEP) as a heightmap base or stamp | 2026-10-22 | M1 | Pending (after v1) |

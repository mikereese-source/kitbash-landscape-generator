# KitBash Landscape Generator — Project Context

> Read this at the start of every session. Update it at the end. Rules: [BUILD_RULES.md](../../../BUILD_RULES.md)

**Track:** full
**Stage:** Pre-build
**Current milestone:** M1 — Scale-correct core
**Last updated:** 2026-10-22

## Pre-build checklist
- [x] Design doc approved (2026-10-22) → `DESIGN.md`
- [x] Boundaries approved (2026-10-22) → `DESIGN.md`
- [x] Clickable prototype approved (2026-10-22, v9) → https://claude.ai/artifact/3q2sd89zXBpTX2LemT8Bd1 (source in docs/prototype/)
- [x] Test plan approved (2026-10-22) → `TEST_PLAN.md`
- [x] Milestone plan approved (below) (2026-10-22)
- [x] Decision log started → `DECISIONS.md`

## One-line summary
A Blender add-on that replaces A.N.T. Landscape: pick a real landscape type, scale it to your scene without losing its shapes, then shape it with a few plain-language controls.

## Architecture
Blender 5.2 add-on. Geometry Nodes node groups do the terrain (live, non-destructive); a thin Python layer adds the menu entry, panel and presets. Details to be settled in DESIGN.md.

## Where things live
- Code: `apps/landscape-generator/kitbash_landscape_generator/` (Blender extension, junction-linked into Blender 5.2 `extensions/user_default/`, D13)
- Prototype: https://claude.ai/artifact/3q2sd89zXBpTX2LemT8Bd1
- Real app / build: <artifact link or path>

## Milestone plan
Every plan includes an errors & edge cases milestone and a final check.

**Pre-build (no add-on code until all approved)**
| # | Step | Done when |
|---|------|-----------|
| P1 | Design doc | Mike approves DESIGN.md (scope, 12 types, 6 controls) |
| P2 | Cave spike (throwaway test) | A 200 m landscape gets one cave and stalactites through the SDF stage in Blender 5.2; we record voxel size, memory and bake time. Decides if caves stay in v1 |
| P3 | Clickable prototype | HTML mock of the Landscape sidebar tab (simple first view + Advanced) approved by Mike |
| P4 | Test plan | Mike approves TEST_PLAN.md |
| P5 | Type recipes | One reference image + target look per type in a type sheet Mike approves |

**M1 steps (checkpoint after each; Mike OKs before the next)**
| Step | What | Size |
|---|---|---|
| 1.1 | Add-on skeleton: Blender extension folder `kitbash_landscape_generator/` (manifest, `__init__`), Landscape sidebar tab, Add Landscape at the top, scene landscape list | S — done 2026-10-22 |
| 1.2 | Core node group, built from Python: grid at Size X/Y, detail in meters per point, Preview/Final cap, height sampled on position ÷ size | M — done 2026-10-22 |
| 1.3 | Type JSON + first 3 recipes (Rolling Hills, Mountains, Sand Dunes), type gallery in the tab | M — done 2026-10-22 |
| 1.4 | Fit to selection (quick scale buttons and detail readout already done; presets dropped, D21) | S — done 2026-10-22 |
| 1.5 | Headless tests T1–T4, T18, T19; then the gate: checker, rollback zip, Mike sign-off | M |

**Build**
| # | Milestone | Definition of done | Status |
|---|-----------|--------------------|--------|
| M1 | Scale-correct core | The Landscape sidebar tab is in place, and Add Landscape creates a live GN landscape at the 3D cursor. Size X/Y, Fit to selection, meters-per-vertex detail, Preview/Final work. 3 types (Rolling Hills, Mountains, Sand Dunes). Shapes match at 10 m, 100 m and 1 km (T1) | Not started |
| M2 | All types + simple controls | All 11 surface types plus the 6 controls and Randomize. Every control has a plain tooltip. Recipes load from the JSON type file. Realism check: each type's slope spread, relief ratio, height distribution and roughness match measured real elevation data for its reference place | Not started |
| M3 | Terraces + data masks | Terraces/strata control. Height, slope, curvature, flow and deposits stored as named attributes and viewable | Not started |
| M4 | Erosion | Erosion slider (thermal + flow gullies). Bake works. Final build of a 1 km landscape finishes inside the agreed time | Not started |
| M5 | Auto-material | Rock/ground/sand/snow material driven by masks, box-mapped, works in Cycles and Eevee | Not started |
| M6 | Cliffs, caves, stalactites | Side Cliffs, Overhangs, Arches, Stalactites, Stalagmites toggles and the Cave type, through the SDF stage, baked at Final | Not started |
| M7 | Errors & edge cases | Bad input, tiny/huge sizes, too many vertices, missing JSON, undo, save/reopen, old files all handled and tested | Not started |
| Final | Final check + Alpha | Full test run, checker review of whole build vs design doc, prototype vs real add-on walkthrough. Packaged as a Blender extension zip | Not started |

**After v1 (parking list):** stamps and curves, tiling and heightmap export, scattering.

**Project 2 (separate build, after Project 1 Gold):** rewrite the whole tool in three.js for Cargo, reading the same type JSON (D7).

## Gate log
| Milestone | Tests | Checker | Mike sign-off | Rollback point | Docs updated | Date |
|-----------|-------|---------|---------------|----------------|--------------|------|
| M1 | | | | | | |

## Current status
2026-10-22: Kickoff. Read the A.N.T. Landscape source; scale bug traced to noise sampled in world units with a fixed height and clamp. Market research done (RESEARCH.md). Mike picked research features 1–5 for v1. DESIGN.md and milestone plan drafted; awaiting approval. 2026-10-22: P2 cave spike PASSED (SPIKE_P2_CAVES.md, D9). P5 type sheet APPROVED. P3 prototype v6 published with Add button at top and cave layouts; awaiting approval, then M1 starts.

## Outside testing (Beta)
- [ ] Installation guide
- [ ] How-to guide
- [ ] Onboarding guide
- [ ] Bug report channel: <where>
- [ ] Reports triaged before next stage

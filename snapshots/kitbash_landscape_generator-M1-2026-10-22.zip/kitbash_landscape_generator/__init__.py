# SPDX-License-Identifier: GPL-3.0-or-later
"""KitBash Landscape Generator: a sidebar tab that adds landscapes to the scene."""

import json
import os

import bpy
import bpy.utils.previews
from mathutils import Vector
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty
from bpy.types import Operator, Panel, PropertyGroup, UIList

from . import nodes

MODIFIER_NAME = "KB Landscape"
HERE = os.path.dirname(__file__)

with open(os.path.join(HERE, "types.json"), encoding="utf-8") as fh:
    TYPES_FILE = json.load(fh)
TYPES = TYPES_FILE["types"]

# types.json key -> node group input
TYPE_INPUTS = {"recipe": "Recipe", "height": "Height", "feature_scale": "Feature Scale", "detail": "Detail",
               "roughness": "Roughness", "warp": "Warp", "sharpness": "Sharpness"}

_previews = None
_type_items = []  # Blender needs enum items kept alive while the enum is in use


def _type_enum(_self, _context):
    return _type_items


def _load_type_items():
    global _previews
    _previews = bpy.utils.previews.new()
    _type_items.clear()
    for i, (key, t) in enumerate(TYPES.items()):
        path = os.path.join(HERE, "thumbs", key + ".png")
        icon = _previews.load(key, path, 'IMAGE').icon_id if os.path.exists(path) else 0
        _type_items.append((key, t["name"], t["look"], icon, i))


def landscape_modifier(ob):
    if ob is None or not ob.lg.is_landscape:
        return None
    mod = ob.modifiers.get(MODIFIER_NAME)
    return mod if mod and mod.node_group else None


def current_landscape(context):
    """The landscape the tab edits: the active object if it is one, else the one picked in the list.
    So you can select other objects (e.g. for Fit to selection) without losing the landscape."""
    ob = context.active_object
    if landscape_modifier(ob):
        return ob
    scene = context.scene
    if 0 <= scene.lg_index < len(scene.objects):
        ob = scene.objects[scene.lg_index]
        if landscape_modifier(ob):
            return ob
    return None


def sync_object(ob):
    """Push every setting into the node group. Setting a modifier input from Python stores the
    value but doesn't rebuild the landscape in Blender 5.2, so the panel edits ob.lg and this
    writes it across (D19)."""
    mod = landscape_modifier(ob)
    if mod is None:
        return
    props = ob.lg
    values = {name: default for name, _t, default, *_rest in nodes.INPUTS}
    values.update({"Size X": props.size_x, "Size Y": props.size_y, "Final": props.final})
    recipe = TYPES.get(props.land_type, TYPES[TYPES_FILE["default"]])
    values.update({sock: recipe[key] for key, sock in TYPE_INPUTS.items()})
    for name, value in values.items():
        nodes.input_socket(mod, name).value = value
    ob.update_tag()


def _sync(props, _context):
    sync_object(props.id_data)


def _refresh_all():
    """Rebuild an outdated node group and re-push every landscape's settings into it
    (a rebuild resets all modifier inputs to zero)."""
    landscapes = [ob for ob in bpy.data.objects if landscape_modifier(ob)]
    if not landscapes:
        return
    ng = nodes.ensure_group()
    for ob in landscapes:
        ob.modifiers[MODIFIER_NAME].node_group = ng
        sync_object(ob)


@persistent
def _on_load(_dummy):
    _refresh_all()


class LG_ObjectProps(PropertyGroup):
    is_landscape: BoolProperty(name="Is Landscape", default=False)
    land_type: EnumProperty(name="Type", items=_type_enum, update=_sync)
    size_x: FloatProperty(name="Width", description="Width of the landscape in meters",
                          default=200.0, min=1.0, max=100000.0, soft_max=5000.0, unit='LENGTH', update=_sync)
    size_y: FloatProperty(name="Depth", description="Depth of the landscape in meters",
                          default=200.0, min=1.0, max=100000.0, soft_max=5000.0, unit='LENGTH', update=_sync)
    final: BoolProperty(name="Final", description="Full detail for the finished landscape. Off = lighter Preview for editing",
                        default=False, update=_sync)


def _select_listed(scene, _context):
    """Picking a row in the list makes that landscape the active object."""
    if not 0 <= scene.lg_index < len(scene.objects):
        return
    ob = scene.objects[scene.lg_index]
    view_layer = bpy.context.view_layer
    if ob.name not in view_layer.objects:
        return
    for other in view_layer.objects.selected:
        other.select_set(False)
    ob.select_set(True)
    view_layer.objects.active = ob
    if ob.lg.is_landscape:
        scene["lg_type"] = ob.lg.get("land_type", 0)  # show its type without re-triggering the update


def _pick_type(scene, context):
    """Picking a type changes the active landscape; Add Landscape uses it for new ones."""
    ob = current_landscape(context)
    if ob and ob.lg.land_type != scene.lg_type:
        ob.lg.land_type = scene.lg_type
        ob.name = "Landscape_" + TYPES[scene.lg_type]["name"].replace(" ", "")


class LG_OT_add_landscape(Operator):
    bl_idname = "landscape.add"
    bl_label = "Add Landscape"
    bl_description = "Add a new landscape of the picked type at the 3D cursor"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def execute(self, context):
        scene = context.scene
        kind = scene.lg_type
        name = "Landscape_" + TYPES[kind]["name"].replace(" ", "")
        ob = bpy.data.objects.new(name, bpy.data.meshes.new(name))
        ob.location = scene.cursor.location
        ob.lg.is_landscape = True
        ob.modifiers.new(MODIFIER_NAME, 'NODES').node_group = nodes.ensure_group()
        ob.lg.land_type = kind  # also syncs every input
        context.collection.objects.link(ob)
        for other in context.selected_objects:
            other.select_set(False)
        ob.select_set(True)
        context.view_layer.objects.active = ob
        scene.lg_index = list(scene.objects).index(ob)
        return {'FINISHED'}


class LG_OT_scale_size(Operator):
    bl_idname = "landscape.scale_size"
    bl_label = "Scale Landscape"
    bl_description = "Multiply the landscape's width and depth. Shapes stay the same"
    bl_options = {'REGISTER', 'UNDO'}

    factor: FloatProperty(name="Factor", default=2.0, min=0.001, max=1000.0)

    @classmethod
    def poll(cls, context):
        return current_landscape(context) is not None

    def execute(self, context):
        props = current_landscape(context).lg
        props.size_x *= self.factor  # the property's min/max clamp tiny and huge sizes
        props.size_y *= self.factor
        return {'FINISHED'}


FIT_MARGIN = 1.1  # 10% border around the fitted objects


def _fit_sources(context):
    return [o for o in context.selected_objects if not o.lg.is_landscape and o.type != 'CAMERA' and o.type != 'LIGHT']


class LG_OT_fit_selection(Operator):
    bl_idname = "landscape.fit_selection"
    bl_label = "Fit to Selection"
    bl_description = ("Resize the landscape so it covers the selected objects, with a margin. "
                      "It stays where it is; place it with the 3D cursor")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if current_landscape(context) is None:
            return False
        if not _fit_sources(context):
            cls.poll_message_set("Select the objects to cover first")
            return False
        return True

    def execute(self, context):
        ob = current_landscape(context)
        cx, cy = ob.matrix_world.translation.xy
        reach_x = reach_y = 0.0
        for src in _fit_sources(context):
            for corner in src.bound_box:
                x, y, _z = src.matrix_world @ Vector(corner)
                reach_x, reach_y = max(reach_x, abs(x - cx)), max(reach_y, abs(y - cy))
        # Sized around the landscape's own centre, so it covers them without moving.
        ob.lg.size_x = max(2 * reach_x * FIT_MARGIN, 1.0)
        ob.lg.size_y = max(2 * reach_y * FIT_MARGIN, 1.0)
        return {'FINISHED'}


class LG_UL_landscapes(UIList):
    def draw_item(self, _context, layout, _data, item, _icon, _active_data, _active_prop, _index):
        layout.prop(item, "name", text="", emboss=False, icon='MESH_GRID')

    def filter_items(self, _context, data, propname):
        objects = getattr(data, propname)
        flags = [self.bitflag_filter_item if ob.lg.is_landscape else 0 for ob in objects]
        return flags, []


class LG_PT_main(Panel):
    bl_label = "KitBash Landscape Generator"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Landscape"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        row = layout.row()
        row.scale_y = 1.6
        row.operator(LG_OT_add_landscape.bl_idname, icon='ADD')

        box = layout.box()
        box.label(text="In this scene")
        if any(ob.lg.is_landscape for ob in scene.objects):
            box.template_list("LG_UL_landscapes", "", scene, "objects", scene, "lg_index", rows=3)
        else:
            col = box.column(align=True)
            col.label(text="No landscapes yet.")
            col.label(text="Pick a type, then press Add Landscape.")

        box = layout.box()
        box.label(text="Landscape type")
        box.template_icon_view(scene, "lg_type", show_labels=True, scale=6.0, scale_popup=5.0)
        picked = TYPES[scene.lg_type]
        col = box.column(align=True)
        col.label(text=picked["name"])
        col.label(text=picked["look"])
        header, body = box.panel("lg_all_types", default_closed=True)
        header.label(text="All types")
        header.prop(scene, "lg_types_view", expand=True, icon_only=True)
        if body:
            if scene.lg_types_view == 'LIST':
                body.column(align=True).prop(scene, "lg_type", expand=True)
            else:
                grid = body.grid_flow(row_major=True, columns=0, even_columns=True, even_rows=True)
                for key, name, _look, icon, _i in _type_items:
                    cell = grid.column(align=True)
                    cell.template_icon(icon_value=icon, scale=4.0)
                    cell.prop_enum(scene, "lg_type", key, text=name)

        ob = current_landscape(context)
        if ob is None:
            return
        mod = landscape_modifier(ob)
        props = ob.lg

        box = layout.box()
        box.label(text="Size")
        for factors in ((2, 4, 8), (1 / 2, 1 / 4, 1 / 8)):
            row = box.row(align=True)
            for f in factors:
                label = f"{f:g}X" if f > 1 else f"1/{round(1 / f)}"
                row.operator(LG_OT_scale_size.bl_idname, text=label).factor = f
        col = box.column(align=True)
        col.prop(props, "size_x")
        col.prop(props, "size_y")
        box.operator(LG_OT_fit_selection.bl_idname, icon='FULLSCREEN_ENTER')
        col = box.column()
        col.label(text="Shapes stay the same at any size.")

        row = box.row(align=True)
        row.label(text="Detail")
        row.prop(props, "final", text="Final" if props.final else "Preview", toggle=True)
        res = nodes.input_socket(mod, "Final Resolution" if props.final else "Preview Resolution").value
        size_x, size_y = props.size_x, props.size_y
        spacing = max(size_x, size_y) / res
        points = (round(size_x / spacing) + 1) * (round(size_y / spacing) + 1)
        box.label(text=f"A point every {spacing:.2f} m · {points / 1000:,.0f} k points")


classes = (LG_ObjectProps, LG_OT_add_landscape, LG_OT_scale_size, LG_OT_fit_selection, LG_UL_landscapes, LG_PT_main)


def register():
    _load_type_items()
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Object.lg = PointerProperty(type=LG_ObjectProps)
    bpy.types.Scene.lg_index = IntProperty(default=-1, update=_select_listed)
    bpy.types.Scene.lg_type = EnumProperty(name="Landscape Type", items=_type_enum, update=_pick_type)
    bpy.types.Scene.lg_types_view = EnumProperty(name="View", items=(
        ('LIST', "List", "Show all types as a list", 'LONGDISPLAY', 0),
        ('GRID', "Grid", "Show all types as thumbnails", 'IMGDISPLAY', 1)))
    bpy.app.handlers.load_post.append(_on_load)
    bpy.app.timers.register(_refresh_all, first_interval=0.1)  # landscapes already open when enabled


def unregister():
    if _on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load)
    del bpy.types.Scene.lg_types_view
    del bpy.types.Scene.lg_type
    del bpy.types.Scene.lg_index
    del bpy.types.Object.lg
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    bpy.utils.previews.remove(_previews)

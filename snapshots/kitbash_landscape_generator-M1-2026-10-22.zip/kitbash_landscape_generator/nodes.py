# SPDX-License-Identifier: GPL-3.0-or-later
"""Builds the shared Geometry Nodes group that every landscape uses."""

import bpy

GROUP_NAME = "KB Landscape Core"
GROUP_VERSION = 4  # bump when the tree changes so old files rebuild it

# (name, socket type, default, min, max, description)
INPUTS = (
    ("Size X", 'NodeSocketFloat', 200.0, 1.0, 100000.0, "Width of the landscape in meters"),
    ("Size Y", 'NodeSocketFloat', 200.0, 1.0, 100000.0, "Depth of the landscape in meters"),
    ("Final", 'NodeSocketBool', False, None, None, "Use the Final detail level instead of Preview"),
    ("Preview Resolution", 'NodeSocketInt', 256, 8, 4096, "Points along the longer side while editing"),
    ("Final Resolution", 'NodeSocketInt', 1024, 8, 8192, "Points along the longer side for the finished landscape"),
    ("Recipe", 'NodeSocketInt', 1, 0, 2, "Base shape: 0 hills, 1 mountains, 2 dunes"),
    ("Height", 'NodeSocketFloat', 0.15, 0.0, 1.0, "Height range as a fraction of the landscape's size"),
    ("Feature Scale", 'NodeSocketFloat', 3.0, 0.1, 50.0, "How many main shapes fit across the landscape"),
    ("Detail", 'NodeSocketFloat', 6.0, 0.0, 15.0, "Layers of smaller detail on top of the main shapes"),
    ("Roughness", 'NodeSocketFloat', 0.5, 0.0, 1.0, "Smooth and soft, or bumpy with small detail"),
    ("Warp", 'NodeSocketFloat', 0.2, 0.0, 2.0, "Bends shapes so they look less regular"),
    ("Sharpness", 'NodeSocketFloat', 1.0, 0.2, 4.0, "Above 1: pointier tops and flatter lows"),
    ("Seed", 'NodeSocketInt', 0, -100000, 100000, "Same seed, same landscape"),
)


def _build(ng):
    ng.interface.clear()
    ng.nodes.clear()
    ng.interface.new_socket("Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    for name, stype, default, lo, hi, desc in INPUTS:
        s = ng.interface.new_socket(name, in_out='INPUT', socket_type=stype)
        s.default_value = default
        s.description = desc
        if lo is not None:
            s.min_value, s.max_value = lo, hi

    N, L = ng.nodes, ng.links
    gin = N.new('NodeGroupInput')
    gout = N.new('NodeGroupOutput')
    inp = gin.outputs

    def math(op, a, b=None):
        n = N.new('ShaderNodeMath')
        n.operation = op
        for sock, v in zip(n.inputs, (a, b)):
            if v is None:
                continue
            if isinstance(v, (int, float)):
                sock.default_value = v
            else:
                L.new(v, sock)
        return n.outputs[0]

    def noise(vector, kind, scale, detail, roughness, distortion=None):
        n = N.new('ShaderNodeTexNoise')
        n.noise_dimensions = '3D'
        n.noise_type = kind
        for sock, v in (("Vector", vector), ("Scale", scale), ("Detail", detail),
                        ("Roughness", roughness), ("Distortion", distortion)):
            if v is None:
                continue
            if isinstance(v, (int, float)):
                n.inputs[sock].default_value = v
            else:
                L.new(v, n.inputs[sock])
        return n

    size_x, size_y = inp["Size X"], inp["Size Y"]
    # Reference size: shapes are sampled on position / ref, so they keep their form at any size.
    ref = math('MAXIMUM', size_x, size_y)

    res = N.new('GeometryNodeSwitch')
    res.input_type = 'INT'
    L.new(inp["Final"], res.inputs["Switch"])
    L.new(inp["Preview Resolution"], res.inputs["False"])
    L.new(inp["Final Resolution"], res.inputs["True"])
    spacing = math('DIVIDE', ref, res.outputs[0])

    grid = N.new('GeometryNodeMeshGrid')
    L.new(size_x, grid.inputs["Size X"])
    L.new(size_y, grid.inputs["Size Y"])
    for axis, size in (("X", size_x), ("Y", size_y)):
        to_int = N.new('FunctionNodeFloatToInt')
        to_int.rounding_mode = 'ROUND'
        L.new(math('ADD', math('DIVIDE', size, spacing), 1.0), to_int.inputs[0])
        L.new(to_int.outputs[0], grid.inputs["Vertices " + axis])

    # Normalized position, shifted by the seed so each seed is a different slice of the noise.
    pos = N.new('GeometryNodeInputPosition')
    ref_vec = N.new('ShaderNodeCombineXYZ')
    for i in range(3):
        L.new(ref, ref_vec.inputs[i])
    norm = N.new('ShaderNodeVectorMath')
    norm.operation = 'DIVIDE'
    L.new(pos.outputs[0], norm.inputs[0])
    L.new(ref_vec.outputs[0], norm.inputs[1])
    seed_z = N.new('ShaderNodeCombineXYZ')
    L.new(math('MULTIPLY', inp["Seed"], 7.31), seed_z.inputs["Z"])
    p = N.new('ShaderNodeVectorMath')
    p.operation = 'ADD'
    L.new(norm.outputs[0], p.inputs[0])
    L.new(seed_z.outputs[0], p.inputs[1])
    p = p.outputs[0]
    warp_amount = math('MULTIPLY', inp["Warp"], 4.0)

    # Recipe 0, hills: soft fBM.
    hills = noise(p, 'FBM', inp["Feature Scale"], inp["Detail"], inp["Roughness"], warp_amount).outputs["Fac"]

    # Recipe 1, mountains: fold fBM into ridges (1 - |2n - 1|), square it for knife edges,
    # and let a broad noise decide which ridges grow into peaks. (Blender's own ridged
    # multifractal mostly reads as one soft blob once stretched to 0..1.)
    # Only the big shapes are folded; folding every detail layer turns it into spiky noise.
    ridge_n = noise(p, 'FBM', inp["Feature Scale"], 1.5, 0.5, warp_amount).outputs["Fac"]
    ridge = math('SUBTRACT', 1.0, math('ABSOLUTE', math('SUBTRACT', math('MULTIPLY', ridge_n, 2.0), 1.0)))
    ridge = math('MULTIPLY', ridge, ridge)
    peaks = noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 0.5), 2.0, 0.5).outputs["Fac"]
    rock = noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 4.0), inp["Detail"], inp["Roughness"]).outputs["Fac"]
    mountains = math('ADD', math('MULTIPLY', ridge, math('ADD', 0.15, peaks)),
                     math('MULTIPLY', math('SUBTRACT', rock, 0.5), 0.12))

    # Recipe 2, dunes: an asymmetric sawtooth across the wind (+X), bent into crescents by low noise.
    sep = N.new('ShaderNodeSeparateXYZ')
    L.new(p, sep.inputs[0])
    bend = noise(p, 'FBM', 1.5, 2.0, 0.5).outputs["Fac"]
    across = math('MULTIPLY', math('ADD', sep.outputs["X"],
                                   math('MULTIPLY', math('SUBTRACT', bend, 0.5), inp["Warp"])),
                  inp["Feature Scale"])
    f = math('FRACT', across)
    windward = math('DIVIDE', f, 0.78)            # long gentle rise...
    slip = math('DIVIDE', math('SUBTRACT', 1.0, f), 0.22)  # ...then a steep slip face
    crest = math('MINIMUM', windward, slip)
    envelope = math('ADD', 0.4, noise(p, 'FBM', 1.2, 2.0, 0.5).outputs["Fac"])
    ripples = math('MULTIPLY', math('SINE', math('MULTIPLY', across, 40.0)), 0.015)
    dunes = math('ADD', math('MULTIPLY', crest, envelope), ripples)

    pick = N.new('GeometryNodeIndexSwitch')
    pick.data_type = 'FLOAT'
    while len(pick.index_switch_items) < 3:
        pick.index_switch_items.new()
    L.new(inp["Recipe"], pick.inputs["Index"])
    for i, field in enumerate((hills, mountains, dunes)):
        L.new(field, pick.inputs[i + 1])
    raw = pick.outputs[0]

    # Stretch to 0..1 across this landscape, so Height is the true relief whatever the recipe.
    stats = N.new('GeometryNodeAttributeStatistic')
    stats.data_type = 'FLOAT'
    stats.domain = 'POINT'
    L.new(grid.outputs["Mesh"], stats.inputs["Geometry"])
    L.new(raw, stats.inputs["Attribute"])
    lo, hi = stats.outputs["Min"], stats.outputs["Max"]
    unit = math('DIVIDE', math('SUBTRACT', raw, lo), math('MAXIMUM', math('SUBTRACT', hi, lo), 1e-6))
    shaped = math('POWER', unit, inp["Sharpness"])
    z = math('MULTIPLY', shaped, math('MULTIPLY', inp["Height"], ref))

    offset = N.new('ShaderNodeCombineXYZ')
    L.new(z, offset.inputs["Z"])
    setpos = N.new('GeometryNodeSetPosition')
    L.new(grid.outputs["Mesh"], setpos.inputs["Geometry"])
    L.new(offset.outputs[0], setpos.inputs["Offset"])
    smooth = N.new('GeometryNodeSetShadeSmooth')
    L.new(setpos.outputs[0], smooth.inputs["Geometry"])
    L.new(smooth.outputs[0], gout.inputs["Geometry"])

    ng["kb_version"] = GROUP_VERSION


def ensure_group():
    """Return the shared node group, building or rebuilding it when missing or outdated."""
    ng = bpy.data.node_groups.get(GROUP_NAME)
    if ng is None:
        ng = bpy.data.node_groups.new(GROUP_NAME, 'GeometryNodeTree')
    if ng.get("kb_version") != GROUP_VERSION:
        _build(ng)
    return ng


def input_socket(mod, name):
    """The modifier's value holder for a group input, by its display name (Blender 5.2 API)."""
    for item in mod.node_group.interface.items_tree:
        if item.item_type == 'SOCKET' and item.in_out == 'INPUT' and item.name == name:
            return getattr(mod.properties.inputs, item.identifier)
    raise KeyError(name)

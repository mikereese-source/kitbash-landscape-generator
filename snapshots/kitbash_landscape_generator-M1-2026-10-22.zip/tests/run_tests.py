"""Headless tests for the KitBash Landscape Generator.

Run:  blender -b --factory-startup --python tests/run_tests.py
Exits 1 if any test fails. Tests drive the panel's own properties (ob.lg.*), never the
node inputs directly, so they catch the Blender 5.2 "value set but not rebuilt" trap (D19).
"""

import os
import sys
import traceback

import bpy
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import kitbash_landscape_generator as lg  # noqa: E402

RESULTS = []


def test(tid, name):
    def wrap(fn):
        try:
            detail = fn()
            RESULTS.append((tid, name, True, detail or ""))
        except Exception as e:  # report and keep going
            RESULTS.append((tid, name, False, f"{type(e).__name__}: {e}"))
            traceback.print_exc()
        return fn
    return wrap


def check(cond, msg):
    if not cond:
        raise AssertionError(msg)


def fresh_scene():
    for ob in list(bpy.data.objects):
        bpy.data.objects.remove(ob)
    bpy.context.scene.cursor.location = (0, 0, 0)


def add(kind="mountains", at=(0, 0, 0)):
    scene = bpy.context.scene
    scene.cursor.location = at
    scene.lg_type = kind
    check(bpy.ops.landscape.add() == {'FINISHED'}, "Add Landscape did not finish")
    return bpy.context.view_layer.objects.active


def evaluated_points(ob):
    dg = bpy.context.evaluated_depsgraph_get()
    dg.update()
    ev = ob.evaluated_get(dg)
    me = ev.to_mesh()
    co = np.empty(len(me.vertices) * 3)
    me.vertices.foreach_get("co", co)
    ev.to_mesh_clear()
    return co.reshape(-1, 3)


def set_size(ob, x, y=None):
    ob.lg.size_x = x
    ob.lg.size_y = x if y is None else y


lg.register()
lg._refresh_all()


@test("T1", "Scale keeps shape")
def _t1():
    out = []
    for kind in lg.TYPES:
        fresh_scene()
        ob = add(kind)
        ref = None
        for size in (10.0, 100.0, 1000.0):
            set_size(ob, size)
            z = evaluated_points(ob)[:, 2] / size
            check(np.isfinite(z).all(), f"{kind} at {size} m has broken heights")
            if ref is None:
                ref, span = z, z.max() - z.min()
                check(span > 0, f"{kind} is flat")
                continue
            diff = np.abs(z - ref).max() / span * 100
            check(diff < 1.0, f"{kind} at {size} m differs {diff:.3f}% from 10 m")
        out.append(kind)
    return "same shape at 10 m / 100 m / 1 km for " + ", ".join(out)


@test("T2", "Detail spacing = size / resolution")
def _t2():
    fresh_scene()
    ob = add()
    for final, res in ((False, 256), (True, 1024)):
        ob.lg.final = final
        for size in (10.0, 200.0, 1000.0):
            set_size(ob, size)
            xs = np.unique(np.round(evaluated_points(ob)[:, 0], 6))
            spacing = np.diff(xs).mean()
            want = size / res
            check(abs(spacing - want) / want < 0.05, f"spacing {spacing:.4f} m, want {want:.4f} m")
    return "within 5% for Preview 256 and Final 1024 at 10 m, 200 m, 1 km"


@test("T3", "Fit to selection covers the objects")
def _t3():
    fresh_scene()
    ob = add(at=(5, -5, 0))
    cubes = []
    for loc in ((150, 20, 5), (-40, -90, 5)):
        bpy.ops.mesh.primitive_cube_add(size=10, location=loc)
        cubes.append(bpy.context.view_layer.objects.active)
    for c in cubes:
        c.select_set(True)
    check(bpy.ops.landscape.fit_selection() == {'FINISHED'}, "Fit did not finish")
    pts = evaluated_points(ob)[:, :2] + np.array(ob.location[:2])
    lo, hi = pts.min(0), pts.max(0)
    for c in cubes:
        for corner in c.bound_box:
            x, y, _ = c.matrix_world @ lg.Vector(corner)
            check(lo[0] <= x <= hi[0] and lo[1] <= y <= hi[1], f"corner ({x:.0f}, {y:.0f}) not covered")
    check(tuple(ob.location) == (5, -5, 0), "Fit moved the landscape")
    for o in bpy.context.selected_objects:
        o.select_set(False)
    check(not bpy.ops.landscape.fit_selection.poll(), "Fit should be greyed out with nothing selected")
    return f"covers both cubes; landscape stayed at the cursor; size {ob.lg.size_x:.0f} x {ob.lg.size_y:.0f} m"


@test("T4", "Preview vs Final point counts")
def _t4():
    fresh_scene()
    ob = add()
    set_size(ob, 200.0)
    n_prev = len(evaluated_points(ob))
    ob.lg.final = True
    n_final = len(evaluated_points(ob))
    check(n_prev == 257 * 257, f"Preview has {n_prev} points, want {257 * 257}")
    check(n_final == 1025 * 1025, f"Final has {n_final} points, want {1025 * 1025}")
    return f"Preview {n_prev:,} / Final {n_final:,} points"


@test("T18", "Landscape tab and Add Landscape")
def _t18():
    fresh_scene()
    panel = bpy.types.LG_PT_main
    check(panel.bl_space_type == 'VIEW_3D' and panel.bl_region_type == 'UI', "panel is not in the sidebar")
    check(panel.bl_category == "Landscape", f"tab is '{panel.bl_category}'")
    check(panel.bl_label == "KitBash Landscape Generator", f"header is '{panel.bl_label}'")
    ob = add(at=(12, 34, 0))
    check(tuple(ob.location) == (12, 34, 0), "not placed at the 3D cursor")
    check(ob.lg.is_landscape and lg.landscape_modifier(ob), "not a live landscape")
    return "sidebar tab 'Landscape'; Add places a live landscape at the 3D cursor (button position: manual check)"


@test("T19", "Landscape list")
def _t19():
    fresh_scene()
    a = add("hills", (0, 0, 0))
    b = add("dunes", (300, 0, 0))
    bpy.ops.mesh.primitive_cube_add()
    scene = bpy.context.scene
    # UILists can't be built outside a UI draw, so call the filter with a stand-in self.
    stand_in = type("UL", (), {"bitflag_filter_item": 1 << 30})()
    flags, _ = lg.LG_UL_landscapes.filter_items(stand_in, bpy.context, scene, "objects")
    listed = {ob.name for ob, f in zip(scene.objects, flags) if f}
    check(listed == {a.name, b.name}, f"list shows {sorted(listed)}")
    scene.lg_index = list(scene.objects).index(a)
    check(bpy.context.view_layer.objects.active == a, "picking a row did not make it active")
    return f"lists only the 2 landscapes; picking a row makes it active"


print("\n=== KitBash Landscape Generator tests ===")
for tid, name, ok, detail in RESULTS:
    print(f"{'PASS' if ok else 'FAIL'}  {tid:4} {name}: {detail}")
failed = [r for r in RESULTS if not r[2]]
print(f"{len(RESULTS) - len(failed)}/{len(RESULTS)} passed")
sys.exit(1 if failed else 0)

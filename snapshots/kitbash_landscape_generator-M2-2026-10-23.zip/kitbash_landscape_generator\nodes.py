# SPDX-License-Identifier: GPL-3.0-or-later
"""Builds the shared Geometry Nodes group that every landscape uses."""

import bpy

GROUP_NAME = "KB Landscape Core"
GROUP_VERSION = 34  # bump when the tree changes so old files rebuild it

# (name, socket type, default, min, max, description)
INPUTS = (
    ("Size X", 'NodeSocketFloat', 200.0, 1.0, 100000.0, "Width of the landscape in meters"),
    ("Size Y", 'NodeSocketFloat', 200.0, 1.0, 100000.0, "Depth of the landscape in meters"),
    ("Final", 'NodeSocketBool', False, None, None, "Use the Final detail level instead of Preview"),
    ("Preview Resolution", 'NodeSocketInt', 512, 8, 8192, "Points along the longer side while editing"),
    ("Final Resolution", 'NodeSocketInt', 2048, 8, 8192, "Points along the longer side for the finished landscape"),
    ("Ultra", 'NodeSocketBool', False, None, None, "Hero detail: Ultra Resolution instead of Final"),
    ("Ultra Resolution", 'NodeSocketInt', 4096, 8, 16384, "Points along the longer side for hero shots"),
    ("Recipe", 'NodeSocketInt', 1, 0, 12, "Base shape: see types.json notes"),
    ("Height", 'NodeSocketFloat', 0.15, 0.0, 2.0, "Height range as a fraction of the landscape's size"),
    ("Feature Scale", 'NodeSocketFloat', 3.0, 0.1, 50.0, "How many main shapes fit across the landscape"),
    ("Detail", 'NodeSocketFloat', 6.0, 0.0, 15.0, "Layers of smaller detail on top of the main shapes"),
    ("Rock", 'NodeSocketFloat', 0.5, 0.0, 2.0, "How much real-size rock grain steep and high ground gets (per type)"),
    ("Grain Roughness", 'NodeSocketFloat', 0.5, 0.3, 0.8, "How fast rock grain fades with size: higher = rubblier at 1 m (per type, from lidar)"),
    ("Roughness", 'NodeSocketFloat', 0.5, 0.0, 1.0, "Smooth and soft, or bumpy with small detail"),
    ("Warp", 'NodeSocketFloat', 0.2, 0.0, 2.0, "Bends shapes so they look less regular"),
    ("Sharpness", 'NodeSocketFloat', 1.0, 0.2, 4.0, "Above 1: pointier tops and flatter lows"),
    ("Seed", 'NodeSocketInt', 0, -100000, 100000, "Same seed, same landscape"),
    # Per-type style and controls; what each means is set per type in types.json.
    ("Style", 'NodeSocketInt', 0, 0, 15, "Per-type style (e.g. volcano: strato, shield, cinder, caldera)"),
    ("P1", 'NodeSocketFloat', 0.5, -100.0, 100.0, "Per-type control 1"),
    ("P2", 'NodeSocketFloat', 0.5, -100.0, 100.0, "Per-type control 2"),
    ("P3", 'NodeSocketFloat', 0.5, -100.0, 100.0, "Per-type control 3"),
    ("P4", 'NodeSocketFloat', 0.0, -100.0, 100.0, "Per-type control 4"),
    ("P5", 'NodeSocketFloat', 0.5, -100.0, 100.0, "Per-type control 5"),
    ("P6", 'NodeSocketFloat', 0.5, -100.0, 100.0, "Per-type control 6"),
)


def _build(ng, recipe):
    ng.interface.clear()
    ng.nodes.clear()
    ng.interface.new_socket("Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    for name, stype, default, lo, hi, desc in INPUTS:
        s = ng.interface.new_socket(name, in_out='INPUT', socket_type=stype)
        s.default_value = default
        s.description = desc
        if lo is not None:
            s.min_value, s.max_value = lo, hi

    N, L = ng.nodes, ng.links
    gin = N.new('NodeGroupInput')
    gout = N.new('NodeGroupOutput')
    inp = gin.outputs

    def math(op, a, b=None):
        n = N.new('ShaderNodeMath')
        n.operation = op
        for sock, v in zip(n.inputs, (a, b)):
            if v is None:
                continue
            if isinstance(v, (int, float)):
                sock.default_value = v
            else:
                L.new(v, sock)
        return n.outputs[0]

    def noise(vector, kind, scale, detail, roughness, distortion=None):
        n = N.new('ShaderNodeTexNoise')
        n.noise_dimensions = '3D'
        n.noise_type = kind
        for sock, v in (("Vector", vector), ("Scale", scale), ("Detail", detail),
                        ("Roughness", roughness), ("Distortion", distortion)):
            if v is None:
                continue
            if isinstance(v, (int, float)):
                n.inputs[sock].default_value = v
            else:
                L.new(v, n.inputs[sock])
        return n

    def smooth(x, edge0, edge1):
        """0 below edge0, 1 above edge1, smooth in between."""
        n = N.new('ShaderNodeMapRange')
        n.interpolation_type = 'SMOOTHSTEP'
        for sock, v in (("Value", x), ("From Min", edge0), ("From Max", edge1)):
            if isinstance(v, (int, float)):
                n.inputs[sock].default_value = v
            else:
                L.new(v, n.inputs[sock])
        return n.outputs["Result"]

    def vec(x, y, z):
        n = N.new('ShaderNodeCombineXYZ')
        for sock, v in zip(n.inputs, (x, y, z)):
            if isinstance(v, (int, float)):
                sock.default_value = v
            else:
                L.new(v, sock)
        return n.outputs[0]

    def soft_ridge(n, width):
        """1 - |2n - 1| with a rounded crest: `width` 0 = knife edge, 1 = broad and round."""
        d = math('SUBTRACT', math('MULTIPLY', n, 2.0), 1.0)
        k = math('ADD', 0.02, math('MULTIPLY', width, 0.45))
        soft = math('SUBTRACT', math('SQRT', math('ADD', math('MULTIPLY', d, d), math('MULTIPLY', k, k))), k)
        span = math('SUBTRACT', math('SQRT', math('ADD', 1.0, math('MULTIPLY', k, k))), k)
        return math('SUBTRACT', 1.0, math('DIVIDE', soft, span))

    size_x, size_y = inp["Size X"], inp["Size Y"]
    # Reference size: shapes are sampled on position / ref, so they keep their form at any size.
    ref = math('MAXIMUM', size_x, size_y)

    res = N.new('GeometryNodeSwitch')
    res.input_type = 'INT'
    L.new(inp["Final"], res.inputs["Switch"])
    L.new(inp["Preview Resolution"], res.inputs["False"])
    L.new(inp["Final Resolution"], res.inputs["True"])
    ultra = N.new('GeometryNodeSwitch')
    ultra.input_type = 'INT'
    L.new(inp["Ultra"], ultra.inputs["Switch"])
    L.new(res.outputs[0], ultra.inputs["False"])
    L.new(inp["Ultra Resolution"], ultra.inputs["True"])
    res = ultra
    spacing = math('DIVIDE', ref, res.outputs[0])
    # Shape layers stop at a real size (~0.25 m wavelength); below that the rock grain takes over (R2).
    detail = math('MINIMUM', inp["Detail"], math('MAXIMUM', math('LOGARITHM', math('DIVIDE', ref,
                  math('MULTIPLY', inp["Feature Scale"], 0.25)), 2.0), 0.0))

    grid = N.new('GeometryNodeMeshGrid')
    L.new(size_x, grid.inputs["Size X"])
    L.new(size_y, grid.inputs["Size Y"])
    for axis, size in (("X", size_x), ("Y", size_y)):
        to_int = N.new('FunctionNodeFloatToInt')
        to_int.rounding_mode = 'ROUND'
        L.new(math('ADD', math('DIVIDE', size, spacing), 1.0), to_int.inputs[0])
        L.new(to_int.outputs[0], grid.inputs["Vertices " + axis])

    # Normalized position, shifted by the seed so each seed is a different slice of the noise.
    pos = N.new('GeometryNodeInputPosition')
    ref_vec = N.new('ShaderNodeCombineXYZ')
    for i in range(3):
        L.new(ref, ref_vec.inputs[i])
    norm = N.new('ShaderNodeVectorMath')
    norm.operation = 'DIVIDE'
    L.new(pos.outputs[0], norm.inputs[0])
    L.new(ref_vec.outputs[0], norm.inputs[1])
    # Seed offsets stay small (wrapped): an offset in the hundreds of thousands leaves 32-bit floats
    # only ~0.03-0.06 units of precision, which snapped noise and Voronoi into blocks and rings.
    seed_val = math('FLOORED_MODULO', math('MULTIPLY', inp["Seed"], 7.31), 89.7)
    seed_z = N.new('ShaderNodeCombineXYZ')
    L.new(seed_val, seed_z.inputs["Z"])
    p = N.new('ShaderNodeVectorMath')
    p.operation = 'ADD'
    L.new(norm.outputs[0], p.inputs[0])
    L.new(seed_z.outputs[0], p.inputs[1])
    p_unbent = p.outputs[0]
    p = p.outputs[0]
    bend_n = N.new('ShaderNodeTexNoise')
    bend_n.noise_dimensions = '3D'
    L.new(p, bend_n.inputs["Vector"])
    bend_n.inputs["Scale"].default_value = 1.3
    bend_n.inputs["Detail"].default_value = 1.0
    centred = N.new('ShaderNodeVectorMath')
    centred.operation = 'SUBTRACT'
    L.new(bend_n.outputs["Color"], centred.inputs[0])
    centred.inputs[1].default_value = (0.5, 0.5, 0.5)
    push = N.new('ShaderNodeVectorMath')
    push.operation = 'SCALE'
    L.new(centred.outputs[0], push.inputs[0])
    L.new(math('MULTIPLY', inp["Warp"], 0.35), push.inputs["Scale"])
    flat = N.new('ShaderNodeVectorMath')  # keep the warp in the ground plane
    flat.operation = 'MULTIPLY'
    L.new(push.outputs[0], flat.inputs[0])
    flat.inputs[1].default_value = (1.0, 1.0, 0.0)
    warped = N.new('ShaderNodeVectorMath')
    warped.operation = 'ADD'
    L.new(p, warped.inputs[0])
    L.new(flat.outputs[0], warped.inputs[1])
    p = warped.outputs[0]
    warp_amount = 0.0  # no noise Distortion anywhere (it streaks)
    # Voronoi patterns are 2D: a flat slice through 3D cells mostly misses their sites, which made
    # craters, rocks and cones sparse. The seed shifts them sideways instead.
    seed_xy = N.new('ShaderNodeVectorMath')
    seed_xy.operation = 'ADD'
    L.new(p_unbent, seed_xy.inputs[0])
    seed_shift = N.new('ShaderNodeCombineXYZ')
    L.new(math('FLOORED_MODULO', math('MULTIPLY', inp["Seed"], 3.17), 61.3), seed_shift.inputs["X"])
    L.new(math('FLOORED_MODULO', math('MULTIPLY', inp["Seed"], 5.29), 73.1), seed_shift.inputs["Y"])
    L.new(seed_shift.outputs[0], seed_xy.inputs[1])
    p2 = seed_xy.outputs[0]

    # Recipe 0, hills: soft fBM.
    hills = noise(p, 'FBM', inp["Feature Scale"], detail, inp["Roughness"], warp_amount).outputs["Fac"]

    # Recipe 1, mountains: fold fBM into ridges (1 - |2n - 1|), square it for knife edges,
    # and let a broad noise decide which ridges grow into peaks. (Blender's own ridged
    # multifractal mostly reads as one soft blob once stretched to 0..1.)
    # Only the big shapes are folded; folding every detail layer turns it into spiky noise.
    ridge_n = noise(p, 'FBM', inp["Feature Scale"], 1.5, 0.5, warp_amount).outputs["Fac"]
    # P1 ridge width: rounds the crest (thickness) and eases the falloff.
    rd = math('SUBTRACT', math('MULTIPLY', ridge_n, 2.0), 1.0)
    rk = math('ADD', 0.02, math('MULTIPLY', inp["P1"], 0.45))
    rsoft = math('SUBTRACT', math('SQRT', math('ADD', math('MULTIPLY', rd, rd), math('MULTIPLY', rk, rk))), rk)
    rspan = math('SUBTRACT', math('SQRT', math('ADD', 1.0, math('MULTIPLY', rk, rk))), rk)
    ridge = math('SUBTRACT', 1.0, math('DIVIDE', rsoft, rspan))
    ridge = math('POWER', ridge, math('SUBTRACT', 2.5, math('MULTIPLY', inp["P1"], 1.5)))
    peaks = noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 0.5), 2.0, 0.5).outputs["Fac"]
    rock = noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 4.0), detail, inp["Roughness"]).outputs["Fac"]
    mountains = math('ADD', math('MULTIPLY', ridge, math('ADD', 0.15, peaks)),
                     math('MULTIPLY', math('SUBTRACT', rock, 0.5), 0.12))

    # Recipe 2, dunes: an asymmetric sawtooth across the wind (+X), bent into crescents by low noise.
    sep = N.new('ShaderNodeSeparateXYZ')
    L.new(p, sep.inputs[0])
    bend = noise(p, 'FBM', 1.5, 2.0, 0.5).outputs["Fac"]

    spacing_jitter = math('MULTIPLY', math('SUBTRACT', noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 0.7), 1.0, 0.5)
                                             .outputs["Fac"], 0.5), 0.9)

    def dune_field(angle, windward_share, bend_amount):
        """Sawtooth crests across the wind at `angle` (radians): a long gentle windward rise,
        then a steep slip face. Returns (crest 0..1, phase along the wind)."""
        along = math('ADD', math('MULTIPLY', sep.outputs["X"], math('COSINE', angle)),
                     math('MULTIPLY', sep.outputs["Y"], math('SINE', angle)))
        phase = math('MULTIPLY', math('ADD', along, math('MULTIPLY', math('SUBTRACT', bend, 0.5),
                                                         math('MULTIPLY', inp["Warp"], bend_amount))),
                     inp["Feature Scale"])
        phase = math('ADD', phase, spacing_jitter)  # real dune spacing is uneven (R3 lidar)
        f = math('FRACT', phase)
        rise = math('DIVIDE', f, windward_share)
        slip = math('DIVIDE', math('SUBTRACT', 1.0, f), 1.0 - windward_share)
        return math('MINIMUM', rise, slip), phase

    def pick_field(index, fields):
        n = N.new('GeometryNodeIndexSwitch')
        n.data_type = 'FLOAT'
        while len(n.index_switch_items) < len(fields):
            n.index_switch_items.new()
        L.new(index, n.inputs["Index"])
        for i, fld in enumerate(fields):
            L.new(fld, n.inputs[i + 1])
        return n.outputs[0]

    wind = inp["P1"]
    envelope = math('ADD', 0.4, noise(p, 'FBM', 1.2, 2.0, 0.5).outputs["Fac"])
    crescent, wind_phase = dune_field(wind, 0.78, 1.0)
    # Break crests into separate dunes of about one spacing across, with open sand between
    # (White Sands lidar, docs/REALISM.md R3).
    # One smooth octave, wide ramp: crests taper out along their length instead of being cut off.
    pieces = noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 1.3), 0.0, 0.5).outputs["Fac"]
    crescent = math('MULTIPLY', crescent, smooth(pieces, 0.3, 0.62))
    # Linear (seif) dunes run along the wind: symmetric ridges, barely bent.
    linear, _ = dune_field(math('ADD', wind, 1.5708), 0.5, 0.3)
    star_a, _ = dune_field(math('ADD', wind, 1.0472), 0.6, 0.6)
    star_b, _ = dune_field(math('ADD', wind, 2.0944), 0.6, 0.6)
    # Star dunes are tall peaks over low sand (Erg Chebbi), so the meeting points are raised to a power.
    star = math('POWER', math('MAXIMUM', math('MAXIMUM', crescent, star_a), star_b), 2.2)
    # Wind ripples at real size (~0.3 m apart, ~1.5 cm high), only where the mesh can draw them.
    ripple_m = 0.3
    ripples = math('SINE', math('MULTIPLY', math('DIVIDE', wind_phase, inp["Feature Scale"]),
                                math('DIVIDE', math('MULTIPLY', ref, 6.2832), ripple_m)))
    # 1.5 cm high, but never more than 2% of the dunes (a 10 m landscape has 20 cm dunes).
    ripples = math('MULTIPLY', ripples, math('MINIMUM', math('DIVIDE', 0.015, math('MAXIMUM', math('MULTIPLY', inp["Height"], ref), 1e-3)), 0.02))
    ripples = math('MULTIPLY', ripples, smooth(math('DIVIDE', ripple_m, spacing), 2.5, 4.0))
    dune_shape = pick_field(inp["Style"], (math('MULTIPLY', crescent, envelope),
                                           math('MULTIPLY', linear, math('ADD', 0.6, math('MULTIPLY', envelope, 0.4))),
                                           math('MULTIPLY', star, envelope)))
    dunes = math('ADD', dune_shape, ripples)

    base = noise(p, 'FBM', inp["Feature Scale"], detail, inp["Roughness"], warp_amount).outputs["Fac"]

    # Recipe 3, seabed: a gently rolling shelf of smooth sand with patches of fractured rocky reef
    # (NOAA 3 m seafloor off Point Lobos, docs/REALISM.md). Reefs stand a few meters proud with
    # crisp edges and lined, broken tops; sand fills between. Ripples are real-size (~0.6 m).
    # The shelf tilts gently offshore and rolls; reefs are only a few percent of its relief.
    shelf = math('ADD', math('MULTIPLY', noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 0.5), 2.0, 0.5).outputs["Fac"], 0.5),
                 math('MULTIPLY', sep.outputs["Y"], 0.3))
    reef_n = noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 1.2), 3.0, 0.55).outputs["Fac"]
    reef = smooth(reef_n, 0.46, 0.54)  # about half the floor, ledgy edges a few meters tall
    bedding = N.new('ShaderNodeVectorMath')  # rock layers make lined, ledgy reef tops
    bedding.operation = 'MULTIPLY'
    L.new(p, bedding.inputs[0])
    bedding.inputs[1].default_value = (1.0, 0.3, 1.0)
    ledges = soft_ridge(noise(bedding.outputs[0], 'FBM', math('MULTIPLY', inp["Feature Scale"], 10.0), detail, 0.6)
                        .outputs["Fac"], 0.15)
    broken = noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 5.0), detail, 0.6).outputs["Fac"]
    reef_h = math('MULTIPLY', reef, math('ADD', 0.012, math('ADD', math('MULTIPLY', ledges, 0.012), math('MULTIPLY', broken, 0.02))))
    sea_ripple_m = 0.6
    s_rip = math('SINE', math('MULTIPLY', math('ADD', sep.outputs["X"], math('MULTIPLY', bend, inp["Warp"])),
                               math('DIVIDE', math('MULTIPLY', ref, 6.2832), sea_ripple_m)))
    s_rip = math('MULTIPLY', math('MULTIPLY', s_rip, math('MINIMUM', math('DIVIDE', 0.03, math('MAXIMUM', math('MULTIPLY', inp["Height"], ref), 1e-3)), 0.01)),
                 math('MULTIPLY', smooth(math('DIVIDE', sea_ripple_m, spacing), 2.5, 4.0), math('SUBTRACT', 1.0, reef)))
    seabed = math('ADD', math('ADD', shelf, reef_h), s_rip)

    # Recipe 4, coastal cliffs: rolling land cut by gullies that deepen toward the edge, a steep
    # bluff band and a low wave-cut platform (Torrey Pines 1 m lidar, docs/REALISM.md).
    shore = noise(p, 'FBM', inp["Feature Scale"], 2.0, 0.5).outputs["Fac"]  # headlands and coves
    # Stretched across the coast, so ravine lines run inland from the edge instead of closing into loops.
    run_inland = N.new('ShaderNodeVectorMath')
    run_inland.operation = 'MULTIPLY'
    L.new(p, run_inland.inputs[0])
    run_inland.inputs[1].default_value = (1.0, 0.18, 1.0)
    gully_n = noise(run_inland.outputs[0], 'FBM', math('MULTIPLY', inp["Feature Scale"], 6.0), 1.5, 0.5).outputs["Fac"]  # few layers: folding the top one made a 25 m repeat
    ravine = math('POWER', soft_ridge(gully_n, 0.2), 2.5)  # V ravines of varied width: 1 along each line, 0 between
    coast = math('ADD', sep.outputs["Y"], math('MULTIPLY', math('SUBTRACT', shore, 0.5), math('MULTIPLY', inp["Warp"], 0.8)))
    coast = math('SUBTRACT', coast, math('MULTIPLY', ravine, 0.03))  # ravines notch the edge
    land = smooth(coast, -0.015, 0.015)
    near_edge = smooth(coast, 0.35, 0.0)  # gullies are deepest at the edge, gone well inland
    plateau = math('ADD', math('ADD', 0.7, math('MULTIPLY', bend, 0.2)), math('MULTIPLY', math('SUBTRACT', base, 0.5), 0.5))
    plateau = math('SUBTRACT', plateau, math('MULTIPLY', math('MULTIPLY', ravine, near_edge), 0.85))
    platform = math('MULTIPLY', noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 3.0), 3.0, 0.5).outputs["Fac"], 0.04)
    cliffs = math('ADD', platform, math('MULTIPLY', land, math('MAXIMUM', plateau, 0.08)))

    # Recipe 5, canyon: a flat plateau cut by a branching network of channels (where the noise
    # crosses 0.5), stepped into rock layers down the walls.
    # Channels follow a low-detail noise so they stay long and continuous; detail only roughens the rim.
    course = noise(p, 'FBM', inp["Feature Scale"], 1.5, 0.5, warp_amount).outputs["Fac"]
    channel = math('ABSOLUTE', math('SUBTRACT', math('MULTIPLY', course, 2.0), 1.0))
    rim = math('MULTIPLY', math('SUBTRACT', base, 0.5), 0.08)
    width = math('ADD', 0.04, math('MULTIPLY', inp["P1"], 0.3))  # P1 channel width
    # Walls spread wide: real canyon walls are long talus slopes between cliff bands (lidar, 30 m and 1 m).
    cut = smooth(math('ADD', channel, rim), 0.0, math('MULTIPLY', width, 1.8))
    cut = math('POWER', cut, math('SUBTRACT', 2.0, math('MULTIPLY', inp["P2"], 1.7)))  # P2 plateau
    wobble = math('MULTIPLY', math('SUBTRACT', noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 3.0), 2.0,
                                                     0.5).outputs["Fac"], 0.5), 0.9)
    layers = 5.0
    # Uneven strata: a slow 1D noise over height stretches some layers and squeezes others.
    strata = math('MULTIPLY', math('SUBTRACT', noise(vec(math('MULTIPLY', cut, 2.3), seed_val, 0.0), 'FBM', 1.0, 2.0, 0.5)
                                   .outputs["Fac"], 0.5), 2.4)
    lu = math('ADD', math('ADD', math('MULTIPLY', cut, layers), wobble), strata)
    # Each layer's hardness: hard rock makes a short cliff over a long slope, soft rock an even ramp.
    hard = noise(vec(math('MULTIPLY', math('FLOOR', lu), 3.7), seed_val, 5.0), 'FBM', 1.0, 0.0, 0.5).outputs["Fac"]
    bench = math('DIVIDE', math('ADD', math('FLOOR', lu), math('POWER', math('FRACT', lu),
                                                                 math('ADD', 1.2, math('MULTIPLY', hard, 1.3)))), layers)
    bench = math('SUBTRACT', bench, math('DIVIDE', math('ADD', wobble, strata), layers))  # keep plateau and floor level
    wall = math('MULTIPLY', smooth(cut, 0.02, 0.12), smooth(cut, 0.98, 0.88))
    canyon = math('ADD', math('MULTIPLY', bench, wall), math('MULTIPLY', cut, math('SUBTRACT', 1.0, wall)))
    # Side gullies and ledges break up the walls at 20-200 m (Grand Canyon 1 m lidar: walls were too smooth).
    side = math('SUBTRACT', soft_ridge(noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 9.0), 2.0, 0.5).outputs["Fac"], 0.3), 0.5)
    canyon = math('ADD', canyon, math('MULTIPLY', side, math('MULTIPLY', wall, 0.12)))

    # Recipe 6, mesa: noise blobs cut into flat-topped blocks with sheer caprock, a talus ramp
    # at their feet, and an occasional second tier.
    blob = noise(p, 'FBM', inp["Feature Scale"], 2.0, 0.45, warp_amount).outputs["Fac"]
    edge = math('SUBTRACT', 0.66, math('MULTIPLY', inp["P1"], 0.2))  # P1 plateau coverage
    top = smooth(blob, edge, math('ADD', edge, 0.015))
    talus = math('MULTIPLY', smooth(blob, math('SUBTRACT', edge, 0.12), edge), 0.22)
    tier = math('MULTIPLY', smooth(blob, math('ADD', edge, 0.08), math('ADD', edge, 0.09)), 0.3)
    desert = math('MULTIPLY', noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 4.0), 2.0, 0.4).outputs["Fac"], 0.02)
    mesa = math('ADD', math('ADD', math('ADD', math('MULTIPLY', top, 0.7), talus), tier), desert)

    def pick_float(index, values):
        n = N.new('GeometryNodeIndexSwitch')
        n.data_type = 'FLOAT'
        while len(n.index_switch_items) < len(values):
            n.index_switch_items.new()
        L.new(index, n.inputs["Index"])
        for i, v in enumerate(values):
            n.inputs[i + 1].default_value = v
        return n.outputs[0]

    x, y = sep.outputs["X"], sep.outputs["Y"]

    # Recipe 7, badlands: dense small knife-edged spurs over a soft base, with many thin soft
    # bands (the colored strata).
    density = math('ADD', 0.5, math('MULTIPLY', inp["P1"], 1.5))  # P1 gully density
    # Only the big spurs are folded; folding the finest layer made an 18 m repeating texture (R3 lidar).
    spur_n = noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], density), math('MINIMUM', detail, 2.0), inp["Roughness"],
                   warp_amount).outputs["Fac"]
    spur = soft_ridge(spur_n, inp["P2"])  # P2 ridge width
    spur = math('POWER', spur, math('SUBTRACT', 3.0, math('MULTIPLY', inp["P2"], 1.8)))
    spur_fine = noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], math('MULTIPLY', density, 4.0)), detail,
                      inp["Roughness"]).outputs["Fac"]
    # Broad benches carry more of the relief than the spurs (Badlands NP 1 m lidar).
    bad = math('ADD', math('ADD', math('MULTIPLY', bend, 0.9), math('MULTIPLY', spur, 0.35)),
               math('MULTIPLY', math('SUBTRACT', spur_fine, 0.5), math('MULTIPLY', spur, 0.12)))
    badlands = bad

    # Recipe 8, volcanic: stacked lava-flow lobes with blocky rough tops, plus a few cinder cones.
    lobe1 = smooth(noise(p, 'FBM', inp["Feature Scale"], 3.0, 0.5, warp_amount).outputs["Fac"], 0.45, 0.5)
    lobe2 = smooth(noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 1.7), 3.0, 0.5, warp_amount).outputs["Fac"], 0.51, 0.55)
    cells = N.new('ShaderNodeTexVoronoi')
    cells.voronoi_dimensions = '2D'
    cells.inputs["Randomness"].default_value = 0.5
    L.new(p2, cells.inputs["Vector"])
    L.new(math('MULTIPLY', inp["Feature Scale"], 2.5), cells.inputs["Scale"])
    cell_rand = N.new('FunctionNodeSeparateColor')
    L.new(cells.outputs["Color"], cell_rand.inputs[0])
    cone_here = smooth(cell_rand.outputs[0], 0.7, 0.72)
    cone = math('MINIMUM', math('MULTIPLY', smooth(cells.outputs["Distance"], 0.24, 0.0), 1.5), 1.0)  # flat top
    cone_crater = math('MULTIPLY', smooth(cells.outputs["Distance"], 0.07, 0.02), 0.3)
    cinder = math('MULTIPLY', math('SUBTRACT', cone, cone_crater), cone_here)
    volcanic = math('ADD', math('ADD', math('MULTIPLY', lobe1, 0.25), math('MULTIPLY', lobe2, 0.18)),
                    math('ADD', math('MULTIPLY', cinder, 0.6), math('MULTIPLY', noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 30.0), 4.0, 0.6).outputs["Fac"], 0.012)))  # rough lava surface

    # Recipe 9, glacial valley: mountains with a broad U-shaped trough carved along X: flat
    # floor, steep smooth walls.
    axis = math('MULTIPLY', math('SUBTRACT', noise(vec(x, 0.0, seed_val), 'FBM', 1.2, 2.0, 0.5).outputs["Fac"], 0.5),
                inp["Warp"])
    across = math('DIVIDE', math('ABSOLUTE', math('SUBTRACT', y, axis)),
                  math('ADD', 0.08, math('MULTIPLY', inp["P1"], 0.3)))  # P1 valley width
    walls = smooth(across, 0.45, 1.0)
    glacial = math('ADD', math('MULTIPLY', walls, math('ADD', 0.15, math('MULTIPLY', mountains, 0.85))),
                   math('MULTIPLY', base, 0.03))

    # Recipe 10, riverbed: a wide nearly flat gravel floor with braided channels running along X
    # (noise stretched along the flow), and banks rising at the sides.
    flow = N.new('ShaderNodeVectorMath')
    flow.operation = 'MULTIPLY'
    L.new(p, flow.inputs[0])
    flow.inputs[1].default_value = (0.25, 1.0, 1.0)
    braids = math('ADD', 0.8, math('MULTIPLY', inp["P1"], 3.2))  # P1 channel count
    braid_n = noise(flow.outputs[0], 'FBM', math('MULTIPLY', inp["Feature Scale"], braids), 3.0, 0.5,
                    warp_amount).outputs["Fac"]
    braid = smooth(math('ABSOLUTE', math('SUBTRACT', math('MULTIPLY', braid_n, 2.0), 1.0)), 0.0, 0.1)
    bank = smooth(math('ABSOLUTE', y), 0.32, 0.48)
    gravel = math('MULTIPLY', noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 12.0), detail, inp["Roughness"]).outputs["Fac"], 0.03)
    riverbed = math('ADD', math('ADD', math('MULTIPLY', braid, 0.25), math('MULTIPLY', bank, 0.7)), gravel)

    # Recipe 11, volcano: one hero volcano at the centre. Style picks the profile
    # (0 stratovolcano, 1 shield, 2 cinder cone, 3 caldera). P1 crater size, P2 steepness,
    # P3 gullies, P4 breach, P5 crater depth, P6 rim thickness. r runs 0 (centre) .. 1 (foot).
    style = inp["Style"]
    radius = math('DIVIDE', pick_float(style, (0.48, 0.5, 0.42, 0.5)),
                  math('DIVIDE', inp["Feature Scale"], 1.5))
    r = math('DIVIDE', math('SQRT', math('ADD', math('MULTIPLY', x, x), math('MULTIPLY', y, y))), radius)
    exponent = math('ADD', pick_float(style, (0.6, 0.3, 0.7, 1.1)),
                    math('MULTIPLY', inp["P2"], pick_float(style, (2.0, 0.6, 0.6, 1.0))))
    crater_r = math('MULTIPLY', inp["P1"], pick_float(style, (0.4, 0.22, 0.6, 0.85)))
    rim_w = math('ADD', 0.015, math('MULTIPLY', inp["P6"], 0.2))   # flat band of rim that always stays
    rim_out = math('MINIMUM', math('ADD', crater_r, rim_w), 0.95)
    # Flank starts at the outer edge of the rim, so the summit keeps its thickness.
    t = math('DIVIDE', math('MAXIMUM', math('SUBTRACT', r, rim_out), 0.0),
             math('MAXIMUM', math('SUBTRACT', 1.0, rim_out), 1e-3))
    flank = math('POWER', math('MAXIMUM', math('SUBTRACT', 1.0, t), 0.0), exponent)
    flank = math('MULTIPLY', flank, smooth(r, 1.05, 0.9))
    # Gullies: broad channels down the flank, fading out before the rim and at the foot.
    theta = math('ARCTAN2', y, x)
    ring = noise(vec(math('MULTIPLY', math('COSINE', theta), 2.0), math('MULTIPLY', math('SINE', theta), 2.0),
                     math('ADD', math('MULTIPLY', r, 1.2), seed_val)), 'FBM', 2.0, 1.0, 0.5).outputs["Fac"]
    channel = math('SUBTRACT', 1.0, soft_ridge(ring, 0.15))
    on_flank = math('MULTIPLY', smooth(t, 0.0, 0.25), smooth(t, 1.0, 0.75))
    gully = math('MULTIPLY', math('MULTIPLY', channel, inp["P3"]),
                 math('MULTIPLY', on_flank, math('MULTIPLY', 0.18, pick_float(style, (1.0, 1.0, 0.3, 1.0)))))
    cone_h = math('SUBTRACT', flank, gully)
    # Crater: steep walls down to a rough floor; P5 sets how deep.
    depth = math('MULTIPLY', inp["P5"], pick_float(style, (0.6, 0.35, 0.8, 0.85)))
    u = math('DIVIDE', r, math('MAXIMUM', crater_r, 1e-3))
    bowl = math('SUBTRACT', 1.0, math('POWER', math('MINIMUM', u, 1.0), 4.0))
    floor_rough = math('MULTIPLY', math('SUBTRACT', noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 12.0),
                                                          4.0, 0.6).outputs["Fac"], 0.5), 0.08)
    inside = math('SUBTRACT', 1.0, math('MULTIPLY', depth, math('ADD', bowl, math('MULTIPLY', floor_rough, bowl))))
    in_crater = smooth(r, crater_r, math('MULTIPLY', crater_r, 0.9))
    lip_c = math('ADD', crater_r, math('MULTIPLY', rim_w, 0.45))
    lip_w = math('ADD', math('MULTIPLY', rim_w, 0.6), 0.01)
    lip = math('MULTIPLY', math('EXPONENT', math('MULTIPLY', math('POWER', math('DIVIDE', math('SUBTRACT', r, lip_c), lip_w),
                                                                      2.0), -1.0)), 0.06)
    cone_h = math('ADD', cone_h, lip)
    shaped_cone = math('ADD', math('MULTIPLY', cone_h, math('SUBTRACT', 1.0, in_crater)),
                       math('MULTIPLY', inside, in_crater))
    # Breach (+X): a lava outflow. Inside a smooth-edged sector the volcano is capped by a ramp
    # that runs from the crater floor down to the foot, so the rim opens and the slope below drops.
    facing = math('DIVIDE', x, math('MAXIMUM', math('MULTIPLY', r, radius), 1e-5))
    open_at = math('SUBTRACT', 1.0, math('MULTIPLY', inp["P4"], 0.6))
    sector = math('MULTIPLY', smooth(facing, open_at, math('ADD', open_at, 0.25)), smooth(inp["P4"], 0.0, 0.05))
    floor_top = math('SUBTRACT', 1.0, depth)
    ramp = math('MULTIPLY', floor_top, math('POWER', math('MAXIMUM', math('SUBTRACT', 1.0,
                                       math('DIVIDE', math('MAXIMUM', math('SUBTRACT', r, crater_r), 0.0),
                                            math('MAXIMUM', math('SUBTRACT', 1.0, crater_r), 1e-3))), 0.0), 1.3))
    capped = math('MINIMUM', shaped_cone, ramp)
    breached = math('ADD', math('MULTIPLY', shaped_cone, math('SUBTRACT', 1.0, sector)), math('MULTIPLY', capped, sector))
    crag = soft_ridge(noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 9.0), 5.0, 0.6).outputs["Fac"], 0.3)
    near_top = math('MULTIPLY', smooth(t, 0.45, 0.0), smooth(r, math('MULTIPLY', crater_r, 0.85), crater_r))
    rocky = math('MULTIPLY', math('SUBTRACT', crag, 0.5), math('MULTIPLY', near_top, 0.07))
    volcano = math('ADD', math('ADD', breached, rocky), math('MULTIPLY', base, 0.04))

    # Recipe 12, craters: an impact-cratered surface, tuned against LROC 2 m elevation of the Moon
    # (Linne, Apollo 14 and 16; docs/REALISM.md). P1 count, P2 size, P3 surface age, P4 variety.
    # Heights are built in true proportion (normalised-position units), so depth/diameter holds:
    # fresh craters 0.2 deep, rim 0.035 D, worn ones 0.03. Each crater has its own age; Age shifts the
    # mix, so an old surface is mostly soft "ghost" craters with a few fresh ones, as on the Moon.
    # Each point sees its two nearest crater sites (Voronoi F1, F2); the nearest cuts into the other.
    density = math('ADD', 0.03, math('MULTIPLY', inp["P1"], 0.97))  # share of sites that get a crater
    # Wear spread: fresh-crater share ~70% at Age 0, ~5% at 0.6 (the Apollo fields), ~1% at 1.
    age_k = math('MULTIPLY', 0.36, math('EXPONENT', math('MULTIPLY', inp["P3"], 4.9)))
    regolith = noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 12.0), detail,
                     math('ADD', 0.4, math('MULTIPLY', inp["Roughness"], 0.25))).outputs["Fac"]
    rolling = noise(p, 'FBM', math('MULTIPLY', inp["Feature Scale"], 0.6), 3.0, 0.5).outputs["Fac"]
    rolling = math('MULTIPLY', math('SUBTRACT', rolling, 0.5), 0.08)
    # Crater relief builds up on its own and the rolling ground is added last: erasing toward zero
    # then only removes older crater relief, never cuts a step into the slope.
    surface = math('MULTIPLY', math('SUBTRACT', regolith, 0.5), math('ADD', 0.0005, math('MULTIPLY', inp["Roughness"], 0.002)))

    def crater_layer(h, scale, old_bias, detailed):
        prev = None  # the second-nearest crater's relief, which the nearest one cuts into
        for feature in ('F2', 'F1'):  # nearest site last, so it sits on top
            cells = N.new('ShaderNodeTexVoronoi')
            cells.voronoi_dimensions = '2D'
            cells.feature = feature
            cells.inputs["Randomness"].default_value = 0.8
            L.new(p2, cells.inputs["Vector"])
            L.new(scale, cells.inputs["Scale"])
            rnd = N.new('FunctionNodeSeparateColor')
            L.new(cells.outputs["Color"], rnd.inputs[0])
            r_size, r_keep, r_shape = rnd.outputs[0], rnd.outputs[1], rnd.outputs[2]
            exists = smooth(r_keep, math('ADD', density, 0.02), density)
            # This crater's wear: 0 fresh .. 1 a ghost. Older layers (bigger craters) lean old.
            u = math('FRACT', math('MULTIPLY', math('ADD', r_size, r_shape), 31.7))
            wear = math('SUBTRACT', 1.0, math('POWER', math('SUBTRACT', 1.0, u), age_k))
            bias = math('MULTIPLY', old_bias, math('ADD', 0.3, math('MULTIPLY', inp["P3"], 0.7)))
            wear = math('ADD', bias, math('MULTIPLY', wear, math('SUBTRACT', 1.0, bias)))
            fresh = math('SUBTRACT', 1.0, wear)
            # Vector from the crater centre. Voronoi "Position" is in input space, so measure there.
            rel = N.new('ShaderNodeVectorMath')
            rel.operation = 'SUBTRACT'
            L.new(p2, rel.inputs[0])
            L.new(cells.outputs["Position"], rel.inputs[1])
            here = N.new('ShaderNodeVectorMath')
            here.operation = 'SCALE'
            L.new(rel.outputs[0], here.inputs[0])
            L.new(scale, here.inputs["Scale"])
            rs = N.new('ShaderNodeSeparateXYZ')
            L.new(here.outputs[0], rs.inputs[0])
            ang = math('MULTIPLY', r_shape, 6.2832)
            ca, sa = math('COSINE', ang), math('SINE', ang)
            lx = math('ADD', math('MULTIPLY', rs.outputs[0], ca), math('MULTIPLY', rs.outputs[1], sa))
            ly = math('SUBTRACT', math('MULTIPLY', rs.outputs[1], ca), math('MULTIPLY', rs.outputs[0], sa))
            # Nearly all craters are round; a rare low-angle impact makes a clear oval.
            f1 = math('FRACT', math('MULTIPLY', r_shape, 3.7))
            ly = math('MULTIPLY', ly, math('ADD', math('ADD', 1.0, math('MULTIPLY', f1, 0.06)),
                                          math('MULTIPLY', smooth(f1, 0.94, 0.98), 0.5)))
            dist = math('SQRT', math('ADD', math('MULTIPLY', lx, lx), math('MULTIPLY', ly, ly)))
            size = math('MULTIPLY', math('ADD', 0.14, math('MULTIPLY', inp["P2"], 0.14)),
                        math('ADD', 0.45, math('MULTIPLY', r_size, 0.55)))
            d = math('DIVIDE', dist, size)
            radius = math('DIVIDE', size, scale)  # crater radius in normalised units
            # Real-size diameter decides simple bowl vs complex crater (Moon: over ~15 km).
            complex_ = smooth(math('MULTIPLY', math('MULTIPLY', radius, ref), 2.0), 12000.0, 20000.0)
            # depth/diameter: 0.2 fresh (Linne 0.205), complex craters shallower, worn ones ~0.03.
            dd = math('MULTIPLY', math('SUBTRACT', 0.2, math('MULTIPLY', complex_, 0.11)),
                      math('SUBTRACT', 1.0, math('MULTIPLY', wear, 0.85)))
            dd = math('MULTIPLY', dd, math('ADD', 0.85, math('MULTIPLY', math('FRACT', math('MULTIPLY', r_size, 7.3)), 0.3)))
            rim_h = math('MULTIPLY', 0.035, math('POWER', fresh, 1.5))
            # Fresh: small flat floor, straight ~32 deg walls, rounded crest, ejecta falling off as d^-4.
            fresh_in = math('SUBTRACT', rim_h, math('MULTIPLY', math('ADD', dd, rim_h),
                                                    math('SUBTRACT', 1.0, smooth(d, 0.12, 1.0))))
            # Complex: flat floor out to half the radius and a central peak.
            floor_cut = math('ADD', math('MULTIPLY', dd, -1.0), math('MULTIPLY', smooth(d, 0.45, 1.0), math('ADD', dd, rim_h)))
            peak = math('MULTIPLY', math('EXPONENT', math('MULTIPLY', math('POWER', math('DIVIDE', d, 0.15), 2.0), -1.0)),
                        math('MULTIPLY', dd, 0.45))
            complex_in = math('ADD', floor_cut, peak)
            fresh_in = math('ADD', fresh_in, math('MULTIPLY', complex_, math('SUBTRACT', complex_in, fresh_in)))
            apron = math('MULTIPLY', math('MULTIPLY', rim_h, math('POWER', math('MAXIMUM', d, 1.0), -4.0)), smooth(d, 2.2, 1.6))
            if detailed:
                theta = math('ARCTAN2', ly, lx)
                # Hummocky ejecta and a slightly uneven rim on fresh craters; faint talus streaks on walls.
                ring_v = vec(math('MULTIPLY', math('COSINE', theta), 2.5), math('MULTIPLY', math('SINE', theta), 2.5),
                             math('ADD', math('MULTIPLY', d, 2.0), math('MULTIPLY', r_size, 53.0)))
                lumps = math('SUBTRACT', noise(ring_v, 'FBM', 1.0, 3.0, 0.55).outputs["Fac"], 0.5)
                apron = math('MULTIPLY', apron, math('ADD', 1.0, math('MULTIPLY', lumps, 1.2)))
                streak_v = vec(math('MULTIPLY', math('COSINE', theta), 7.0), math('MULTIPLY', math('SINE', theta), 7.0),
                               math('MULTIPLY', r_size, 41.0))
                streaks = math('SUBTRACT', noise(streak_v, 'FBM', 1.0, 2.0, 0.5).outputs["Fac"], 0.5)
                wall = math('MULTIPLY', smooth(d, 0.3, 0.6), smooth(d, 1.0, 0.85))
                fresh_in = math('ADD', fresh_in, math('MULTIPLY', math('MULTIPLY', streaks, wall), math('MULTIPLY', dd, math('MULTIPLY', fresh, 0.12))))
            fresh_prof = math('ADD', fresh_in, math('MULTIPLY', math('SUBTRACT', apron, fresh_in), smooth(d, 0.98, 1.02)))
            # Worn: diffusion leaves a wide, soft dish with no rim.
            worn_prof = math('MULTIPLY', math('MULTIPLY', dd, -1.0), math('SUBTRACT', 1.0, smooth(d, 0.0, 1.35)))
            prof = math('ADD', fresh_prof, math('MULTIPLY', wear, math('SUBTRACT', worn_prof, fresh_prof)))
            profile = math('MULTIPLY', math('MULTIPLY', prof, math('MULTIPLY', radius, 2.0)), exists)
            if prev is None:
                prev = profile
                continue
            # Overprint within the layer only: a smaller crater landing on a bigger one is carved into
            # its floor or wall (added), it doesn't flatten a disc into it.
            erase = math('MULTIPLY', smooth(d, 1.05, 0.75), math('MULTIPLY', exists, math('SUBTRACT', 0.9, math('MULTIPLY', wear, 0.6))))
            h = math('ADD', h, math('ADD', math('MULTIPLY', prev, math('SUBTRACT', 1.0, erase)), profile))
        return h

    # Variety spreads the layers apart in size: 0 = all similar, 1 = basins down to pinpricks.
    # Equal site density per layer gives the Moon's size spread, N(>D) ~ D^-2.
    spread = math('ADD', 0.15, math('MULTIPLY', inp["P4"], 0.85))
    count = math('MULTIPLY', inp["Feature Scale"], 1.25)
    craters = surface
    for mult, old_bias, detailed in ((0.35, 0.35, True), (1.0, 0.15, True), (3.0, 0.0, False), (9.0, 0.0, False),
                                     (27.0, 0.0, False), (81.0, 0.0, False)):
        craters = crater_layer(craters, math('MULTIPLY', count, math('POWER', mult, spread)), old_bias, detailed)
    craters = math('ADD', craters, rolling)

    recipes = (hills, mountains, dunes, seabed, cliffs, canyon, mesa, badlands, volcanic, glacial, riverbed, volcano,
               craters)
    # One group per recipe: only the chosen recipe is wired to the output, so Blender never
    # evaluates the other twelve (an Index Switch over fields evaluated them all, ~35% slower).
    chosen = recipes[min(max(recipe, 0), len(recipes) - 1)]
    # Universal anti-alias: blur the heights over 2 neighbouring points before stretching to Height,
    # so no feature is sharper than the mesh can draw and Height stays the exact relief.
    aa = N.new('GeometryNodeBlurAttribute')
    aa.data_type = 'FLOAT'
    L.new(chosen, aa.inputs["Value"])
    # Edge rounding is a real width, the same at every detail level: Preview's 2-point bevel
    # (2 x size / 512), capped at 2 m, never under 2 points. A fixed 2 points shrank the bevel 4x
    # at Final, so steep canyon benches folded into pinched creases (Mike, 2026-10-23).
    bevel_m = math('MINIMUM', math('DIVIDE', math('MULTIPLY', ref, 2.0), 512.0), 2.0)
    aa_iter = N.new('FunctionNodeFloatToInt')
    aa_iter.rounding_mode = 'ROUND'
    L.new(math('MINIMUM', math('MAXIMUM', math('DIVIDE', bevel_m, spacing), 2.0), 16.0), aa_iter.inputs[0])
    L.new(aa_iter.outputs[0], aa.inputs["Iterations"])
    raw = aa.outputs[0]

    # Stretch to 0..1 across this landscape, so Height is the true relief whatever the recipe.
    stats = N.new('GeometryNodeAttributeStatistic')
    stats.data_type = 'FLOAT'
    stats.domain = 'POINT'
    L.new(grid.outputs["Mesh"], stats.inputs["Geometry"])
    L.new(raw, stats.inputs["Attribute"])
    lo, hi = stats.outputs["Min"], stats.outputs["Max"]
    unit = math('DIVIDE', math('SUBTRACT', raw, lo), math('MAXIMUM', math('SUBTRACT', hi, lo), 1e-6))
    shaped = math('POWER', unit, inp["Sharpness"])
    z = math('MULTIPLY', shaped, math('MULTIPLY', inp["Height"], ref))

    offset = N.new('ShaderNodeCombineXYZ')
    L.new(z, offset.inputs["Z"])
    setpos = N.new('GeometryNodeSetPosition')
    L.new(grid.outputs["Mesh"], setpos.inputs["Geometry"])
    L.new(offset.outputs[0], setpos.inputs["Offset"])
    shape = setpos.outputs[0]

    # R2, rock grain in real meters: rough where real land is bare rock (steep or high), nearly
    # smooth on flats and valley floors. Wavelengths from min(30 m, size/16) down to 0.5 m or 2.5 points.
    normal = N.new('GeometryNodeInputNormal').outputs[0]
    nrm = N.new('ShaderNodeSeparateXYZ')
    L.new(normal, nrm.inputs[0])
    steep = smooth(nrm.outputs["Z"], 0.94, 0.75)  # 20 to 41 degrees
    high = smooth(shaped, 0.35, 0.85)
    bare = math('ADD', 0.06, math('MULTIPLY', math('MAXIMUM', steep, math('MULTIPLY', high, 0.35)), 0.94))
    l_max = math('MINIMUM', 30.0, math('DIVIDE', ref, 16.0))
    l_min = math('MAXIMUM', 0.5, math('MULTIPLY', spacing, 2.5))
    octaves = math('MAXIMUM', math('LOGARITHM', math('DIVIDE', l_max, l_min), 2.0), 0.0)
    here = N.new('GeometryNodeInputPosition')
    rock_p = N.new('ShaderNodeVectorMath')
    rock_p.operation = 'ADD'
    L.new(here.outputs[0], rock_p.inputs[0])
    L.new(vec(math('MULTIPLY', seed_val, 13.0), math('MULTIPLY', seed_val, 7.9), 0.0), rock_p.inputs[1])
    grain = noise(rock_p.outputs[0], 'FBM', math('DIVIDE', 1.0, l_max), octaves, inp["Grain Roughness"]).outputs["Fac"]
    amount = math('MULTIPLY', math('MULTIPLY', inp["Rock"], bare),
                  math('MULTIPLY', math('ADD', 0.4, math('MULTIPLY', inp["Roughness"], 1.2)), math('MULTIPLY', l_max, 0.06)))  # top layer weak: stronger made a 20-35 m bump (lidar)
    amount = math('MULTIPLY', amount, smooth(math('DIVIDE', l_max, l_min), 1.0, 1.5))  # none if the mesh can't draw it
    hz = N.new('ShaderNodeSeparateXYZ')
    L.new(here.outputs[0], hz.inputs[0])
    # Push along the surface normal, so steep walls get rough sideways, not just up and down.
    push = math('MULTIPLY', math('SUBTRACT', grain, 0.5), math('MULTIPLY', amount, 2.0))
    total = math('ADD', hz.outputs["Z"], math('MULTIPLY', nrm.outputs["Z"], push))
    # Stretch again so Height stays the exact relief.
    stats2 = N.new('GeometryNodeAttributeStatistic')
    stats2.data_type = 'FLOAT'
    stats2.domain = 'POINT'
    L.new(shape, stats2.inputs["Geometry"])
    L.new(total, stats2.inputs["Attribute"])
    lo2, hi2 = stats2.outputs["Min"], stats2.outputs["Max"]
    final_z = math('MULTIPLY', math('DIVIDE', math('SUBTRACT', total, lo2), math('MAXIMUM', math('SUBTRACT', hi2, lo2), 1e-6)),
                   math('MULTIPLY', inp["Height"], ref))
    offset2 = N.new('ShaderNodeCombineXYZ')
    L.new(math('MULTIPLY', nrm.outputs["X"], push), offset2.inputs["X"])
    L.new(math('MULTIPLY', nrm.outputs["Y"], push), offset2.inputs["Y"])
    L.new(math('SUBTRACT', final_z, hz.outputs["Z"]), offset2.inputs["Z"])
    setpos2 = N.new('GeometryNodeSetPosition')
    L.new(shape, setpos2.inputs["Geometry"])
    L.new(offset2.outputs[0], setpos2.inputs["Offset"])
    shade = N.new('GeometryNodeSetShadeSmooth')
    L.new(setpos2.outputs[0], shade.inputs["Geometry"])
    L.new(shade.outputs[0], gout.inputs["Geometry"])

    ng["kb_version"] = GROUP_VERSION


def ensure_group(recipe=1):
    """Return the node group for one recipe, building or rebuilding it when missing or outdated."""
    name = f"{GROUP_NAME} {recipe:02d}"
    ng = bpy.data.node_groups.get(name)
    if ng is None:
        ng = bpy.data.node_groups.new(name, 'GeometryNodeTree')
    if ng.get("kb_version") != GROUP_VERSION:
        _build(ng, recipe)
    return ng


def input_socket(mod, name):
    """The modifier's value holder for a group input, by its display name (Blender 5.2 API)."""
    for item in mod.node_group.interface.items_tree:
        if item.item_type == 'SOCKET' and item.in_out == 'INPUT' and item.name == name:
            return getattr(mod.properties.inputs, item.identifier)
    raise KeyError(name)
